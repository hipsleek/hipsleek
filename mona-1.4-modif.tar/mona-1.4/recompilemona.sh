#!/bin/sh
#make clean
#make uninstall
#rm -r /home/andreeac/Mona/*
#mkdir /usr/local/new_mona/exec #home/andreeac/Mona/exec
./configure --prefix=/usr/local/new_mona --exec-prefix=/usr/local/new_mona/
make
make install-strip
