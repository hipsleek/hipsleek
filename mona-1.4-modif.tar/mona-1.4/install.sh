#!/bin/sh
#make clean
#make uninstall
#rm -r /home/andreeac/Mona/*
#mkdir /usr/local/new_mona/exec #home/andreeac/Mona/exec
./configure --prefix=/usr/local/new_mona --exec-prefix=/usr/local/new_mona
make
sudo make install-strip
sudo rm /usr/local/bin/mona_inter
sudo ln -s /usr/local/new_mona/bin/mona /usr/local/bin/mona_inter
sudo cp mona_predicates.mona /usr/local/lib/
