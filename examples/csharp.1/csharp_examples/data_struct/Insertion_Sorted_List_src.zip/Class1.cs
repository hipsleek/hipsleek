/********************************************************************
 * Shows a insertion sorted list class that can be used to          *
 * automatically sort the list as elements are added.               *
 *																	*
 * Author:	Ming Lei												*
 * Date:	7-13-05													*
 ********************************************************************/

using System;
using System.IO;
using System.Collections;

namespace InsertionSort
{
	#region Test Class => Class1
	/// <summary>
	/// Test Class body
	///		: contains main entry.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			// Init an insertion sorted list with an integer comparer
			InsertionSortedList iC = new InsertionSortedList(
										new ComparerClass(new ComparerClass.compare_op(compare_int)));
			// Supply data
			iC.Add(20,2,120,78,57,1000,102,17,980);
			
			// Print out items in list
			foreach (int item in iC)
				Console.Write(item.ToString()+", ");

			// Wait user enter and display a separater
			Console.ReadLine();
			Console.WriteLine("==============================");

			// Add some more data, then display the list again
			iC.Add(97,5,1020,450);
			foreach (int item in iC)
				Console.Write(item.ToString()+", ");

			// Wait user response
			Console.ReadLine();
			Console.WriteLine("==============================");

			// Initialize a new insertion sorted list with string comparer
			InsertionSortedList iC2 = new InsertionSortedList(
										new ComparerClass(new ComparerClass.compare_op(compare_str)));

			// Add some items;
			iC2.Add("ihope","bizzard","tooth","faith","dinner","anything");

			// Display them
			foreach (string item in iC2)
				Console.Write(item+", ");
			Console.ReadLine();			
		}

		/// <summary>
		/// Integer compare function
		///		: compare_int compares two int values;
		/// </summary>
		/// <param name="A"></param>
		/// <param name="B"></param>
		/// <returns></returns>
		static int compare_int (object A, object B)
		{
			int int_A = (int)A;
			int int_B = (int)B;
			 
			if (int_A > int_B) return 1;
			if (int_A < int_B) return -1;
			return 0;
		}
		/// <summary>
		/// String compare function
		///		: compare_str compares two strings
		/// </summary>
		/// <param name="A"></param>
		/// <param name="B"></param>
		/// <returns></returns>
		static int compare_str (object A, object B)
		{
			return String.Compare((string)A, (string)B, true);
		}
	}
	#endregion

	#region Class ComparerClass
	/// <summary>
	/// ComparerClass implements IComparer interface
	/// </summary>
	class ComparerClass: IComparer
	{
		#region Delegates
		// Delegates
		// compare_op delegate
		//		: delegate to compare two objects of same type
		public delegate int compare_op(object A, object B);
		#endregion

		compare_op op;
		public ComparerClass(compare_op op) 
		{
			this.op = op;
		}
		#region IComparer Members

		public int Compare(object x, object y)
		{
			try 
			{
				int result = op(x, y);
				return result;
			} 
			catch 
			{
				throw new CompareDataErrorException();
			}
		}

		#endregion
	}
	#endregion

	#region Class InsertionSortedList
	/// <summary>
	/// InsertionSortedList
	///		: Class of sorted list using insertion sort.
	/// </summary>
	class InsertionSortedList: CollectionBase, IEnumerable
	{
		#region Members
		InsertionSortIterator iterator = null;		// Iterator
		IComparer comparer;							// Comparer
		#endregion

		// Initializer supplies the comparer
		public InsertionSortedList(IComparer comparer)
		{
			this.comparer = comparer;
			iterator = new InsertionSortIterator(this);
		}

		#region Overload Add methods
		// Add a single object
		public void Add(object o)
		{
			List.Add(o);
			iterator.isSorted = false;
		}
		// Add a variable length of objects
		public void Add(params object[] add_list)
		{
			foreach(object o in add_list)
				List.Add(o);
			iterator.isSorted = false;
		}
		// Add a collection list of objects
		public void Add(CollectionBase add_list)
		{
			foreach(object o in add_list)
				List.Add(o);
			iterator.isSorted = false;
		}
		#endregion

		// Remove an object
		public void Remove(object o)
		{
			if (List.Contains(o))
				List.Remove(o);
		}

		// Return true if it contains the object
		public bool Contains(object o)
		{
			return List.Contains(o);
		}

		// Indexer
		public object this [int index]
		{
			get 
			{
				return List[index];
			}
		}

		// Insertion sort
		public void Sort(int begin_index)
		{
			// throw if comparer is null;
			if (comparer == null)
				throw new CompareOperatorNotSuppliedException();
			// return if begin_index >= collection length
			if (begin_index >= List.Count - 1)
				return;

			// from begin_index onward to length of list
			for (int i = begin_index; i < List.Count; i++)
			{
				object v = List[i];		// object v to be sorted
				int j = i - 1;			// j is i - 1
				// while j is not zero, look for a position for v
				while (j >= 0 && comparer.Compare(List[j],v) > 0)
				{
					List[j+1] = List[j];
					j--;
				}
				List[j+1] = v;			// found a position -> sort v
			}
		}

		// Get enumerator
		public new IEnumerator GetEnumerator()
		{
			return iterator;
		}
	}
	#endregion

	#region Class InsertionSortIterator
	/// <summary>
	/// Insertion sort iterator
	/// </summary>
	class InsertionSortIterator: IEnumerator
	{
		private bool is_sorted = false;					// is_sorted?
		private InsertionSortedList parent = null;		// parent class
		private int counter = 0;						// the counter
		private int last_sort_pos = 0;					// record last sort position
		// property isSorted
		//		: gets and sets is_sorted
		public bool isSorted							
		{
			get { return is_sorted; }
			set { is_sorted = value; }
		}
		// Constructor
		public InsertionSortIterator(InsertionSortedList parent)
		{
			this.parent = parent;
		}
		// Reset counter
		public void Reset()
		{
			counter = 0;
		}
		// Move to next
		public bool MoveNext()
		{
			if (counter >= parent.Count-1) 
			{
				counter = 0;
				return false;
			}
			counter++;
			return true;
		}
		// Get current
		public object Current
		{
			get 
			{
				// if it is not sorted, sort, then return current
				if (is_sorted == false) 
				{
					//	throw new DataNotSortedException();
					parent.Sort(last_sort_pos+1);
					last_sort_pos = parent.Count-1;
				}
				return parent[counter];
			}
		}
	}
	#endregion

	#region Exception Classes
	class DataNotSortedException: Exception
	{
		public DataNotSortedException()
			: base("Data is not sorted.")
		{
		}
	}

	class CompareOperatorNotSuppliedException: Exception
	{
		public CompareOperatorNotSuppliedException()
			: base("Compare operator not supplied.")
		{
		}
	}

	class CompareDataErrorException: Exception
	{
		public CompareDataErrorException()
			: base("Can't compare data of different type.")
		{
		}
	}
	#endregion
}
