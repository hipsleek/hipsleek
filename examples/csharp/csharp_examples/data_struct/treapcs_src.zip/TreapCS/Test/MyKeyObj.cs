using System;

namespace Test
{
	//
	// demonstrates using a key embedded with an object
	//
	public class MyKeyObj : IComparable
	{
		private int     intKey;
		private string  strData;
		
		public int Key
		{
			get
            {
				return intKey;
			}
			
			set
			{
				intKey = value;
			}
		}
		public string Data
		{
			get
            {
				return strData;
			}
			
			set
			{
				strData = value;
			}
		}
		public MyKeyObj(int key, string data) 
        {
			this.Key    = key;
			this.Data   = data;
		}

		public int CompareTo(object key)
		{
			if(Key > ((MyKeyObj)(key)).Key)
				return 1;
			else
			if(Key < ((MyKeyObj)(key)).Key)
				return -1;
			else
			{
				return 0;
            }
		}
		public override string ToString()
		{
			return Key.ToString();
		}
	}
}
