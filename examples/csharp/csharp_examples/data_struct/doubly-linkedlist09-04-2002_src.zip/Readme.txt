Foley .NET Utilities
Copyright (c) 2002 by Rodney S. Foley

 _____________
[License Stuff]

This program is free software; you can
redistribute it and/or modify it under the
terms of the GNU General Public License as
published by the Free Software Foundation;
either version 2 of the License, or (at your
option) any later version.

This program is distributed in the hope that
it will be useful, but WITHOUT ANY WARRANTY;
without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE. See the GNU General Public License
for more details.

You should have received a copy of the GNU
General Public License along with this
program; if not, write to:

    Free Software Foundation, Inc.,
    59 Temple Place, Suite 330,
    Boston, MA 02111-1307 USA

          - or -

http://opensource.org/licenses/gpl-license.php

 _____________
[Prerequisites]

You need at the very least to have the Microsoft
.NET Framework SDK with SP2 to compile the library.

.NET Framework Download
http://msdn.microsoft.com/netframework/downloads/howtoget.asp

.NET Framework SP2 Download
http://msdn.microsoft.com/netframework/downloads/sp/default.asp

However, I recommend using an IDE like Visual C#.NET
or the free open source #Develop with the .NET Framework.

Visual C#.NET
http://msdn.microsoft.com/vcsharp/

#Develop
http://www.icsharpcode.net/opensource/sd/

 _________
[Compiling]

Currently I only provide a Visual C#.NET solution.  I plan
in a future release to include a NAnt build script.

 _______
[Scripts]

None at this time.

 _______
[The End]

Any questions, comments, or suggestions please check out:

    http://foleyutilities.sourceforge.net

I would appreciate it if you find anything in this project useful and use
them in any way, please, just to drop me a e-mail via sourceforge at:

    http://sourceforge.net/users/rsfoley/
