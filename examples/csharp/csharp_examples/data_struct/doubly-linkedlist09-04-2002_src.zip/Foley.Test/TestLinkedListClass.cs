/* Foley C# Utilities
 * Copyright (C)2002 Rodney S. Foley
 *  
 * This program is free software; you can 
 * redistribute it and/or modify it under the 
 * terms of the GNU General Public License as 
 * published by the Free Software Foundation; 
 * either version 2 of the License, or (at your 
 * option) any later version.
 * 
 * This program is distributed in the hope that 
 * it will be useful, but WITHOUT ANY WARRANTY; 
 * without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR 
 * PURPOSE. See the GNU General Public License 
 * for more details.
 * 
 * You should have received a copy of the GNU 
 * General Public License along with this 
 * program; if not, write to: 
 * 
 *		Free Software Foundation, Inc., 
 *		59 Temple Place, Suite 330, 
 *		Boston, MA 02111-1307 USA
 * 
 *					- or -
 * 
 * http://opensource.org/licenses/gpl-license.php
 */

using System;
using System.Diagnostics;
using Foley.Utilities.Collections;

namespace Foley.Test
{
	/// <summary>
	/// Class used for unit testing: 
	/// Foley.Utilities.Collections.LinkedList
	/// </summary>
	public class TestLinkedListClass
	{
		#region Private Member Variables
		private LinkedList	testList;
		private String[]	testStrings;
		#endregion

		#region Public Constructor
		public TestLinkedListClass()
		{
			Console.WriteLine("Testing LinkedList Class...");
			
			TestInit();
			RunTests();

			Console.WriteLine("LinkedList Class...PASSED");
		}
		#endregion

		#region Private Member Methods
		private void TestInit()
		{
			testList = new LinkedList();
			testStrings = new String[]{ "Safe", "and", "Simple", null, "Life's", "a", "Game", null, 
										"Pumping", "Out", "the", "Same", "Old", "Same", null};
		}

		private void RunTests()
		{
			TestLinkedListAdd();
			TestLinkedListForeach();
			TestLinkedListClear();
			TestLinkedListAddAll();
			TestLinkedListContans();
			TestLinkedListCopyTo();
			TestLinkedListIndexOf();
			TestLinkedListInsertAndRemove();
			TestLinkedListInstertAll();
			TestLinkedListRemoveAt();
			TestLinkedListCount();
			TestLinkedListClone();
		}

		private void TestPassed()
		{
			Console.WriteLine("PASSED");
		}

		private void TestLinkedListAdd()
		{
			Console.Write("Testing LinkedList.Add(object) method...");

			foreach (String s in testStrings)
				testList.Add(s);

			Trace.Assert(testList.Count == testStrings.Length, "TestLinkedListAdd: Failed - Count and Length don't match.");

			for (int i = 0; i < testList.Count; i++)
				Trace.Assert(((string)testList[i]) == testStrings[i], "TestLinkedListAdd: Failed - Objects in list are not same.");
			
			TestPassed();
		}

		private void TestLinkedListForeach()
		{
			Console.Write("Testing LinkedList foreach functionality...");

			int counter = 0;

			foreach (String s in testList)
			{
				Trace.Assert(s == testStrings[counter], "TestLinkedListForeach: Failed");
				counter++;
			}
			
			TestPassed();
		}

		private void TestLinkedListClear()
		{
			Console.Write("Testing LinkedList.Clear() method...");

			testList.Clear();

			Trace.Assert(testList.Count == 0, "TestLinkedListClear: Failed");

			TestPassed();
		}

		private void TestLinkedListAddAll()
		{
			Console.Write("Testing LinkedList.AddAll(ICollection) method...");

			testList.AddAll(testStrings);

			Trace.Assert(testList.Count == testStrings.Length);

			for (int i = 0; i < testList.Count; i++)
				Trace.Assert(((string)testList[i]) == testStrings[i], "TestLinkedListAddAll: Failed");
			
			TestPassed();
		}

		private void TestLinkedListContans()
		{
			Console.Write("Testing LinkedList.Contans(object) method...");

			for (int i = 0; i < testStrings.Length; i++)
				Trace.Assert(testList.Contains(testStrings[i]), "TestLinkedListContans: Failed");

			TestPassed();
		}

		private void TestLinkedListCopyTo()
		{
			Console.Write("Testing LinkedList.CopyTo(Array, int) method...");

			object[] tempArray = new object[testStrings.Length];

			testList.CopyTo(tempArray, 0);

			for (int i = 0; i < tempArray.Length; i++)
				Trace.Assert(((string)tempArray[i]) == ((string)testStrings[i]), "TestLinkedListCopyTo: Copying to begining failed");
			
			tempArray = new object[testStrings.Length * 2];

			testList.CopyTo(tempArray, testStrings.Length);

			for (int i = testStrings.Length, j = 0; i < tempArray.Length; i++, j++)
				Trace.Assert(((string)tempArray[i]) == ((string)testStrings[j]), "TestLinkedListCopyTo: Copying to middle failed");
			
			TestPassed();
		}

		private void TestLinkedListIndexOf()
		{
			Console.Write("Testing LinkedList.IndexOf(object) method...");

			int index = (int)testStrings.Length/3;
			int indexOf = testList.IndexOf(testStrings[index]);

			Trace.Assert(indexOf == index, "TestLinkedListRemoveAt: Failed");

			TestPassed();
		}

		private void TestLinkedListInsertAndRemove()
		{
			Console.Write("Testing LinkedList.Insert(int,object) & Remove(object) methods...");

			int index = (int)testStrings.Length/3;
			string instertString = "INSERTME";

			testList.Insert(index, instertString);

			string retrievedString = (string)testList[index];

			Trace.Assert(instertString == retrievedString, "TestLinkedListInsertAndRemove: Failed - Instered object doesn't match retrieved object.");

			testList.Remove(instertString);

			for (int i = 0; i < testList.Count; i++)
				Trace.Assert(((string)testList[i]) == testStrings[i], "TestLinkedListInsertAndRemove: Failed - Object was not removed correctly.");

			TestPassed();
		}

		private void TestLinkedListInstertAll()
		{
			Console.Write("Testing LinkedList.InstertAll(ICollection) method...");

			LinkedList tempList = new LinkedList(testStrings);

			for (int i = 0; i < tempList.Count; i++)
				Trace.Assert(((string)tempList[i]) == testStrings[i], "TestLinkedListInstertAll: Failed");

			TestPassed();
		}

		private void TestLinkedListRemoveAt()
		{
			Console.Write("Testing LinkedList.RemoveAt(int) method...");

			int index = (int)testStrings.Length/3;
			string instertString = "INSERTME";

			testList.Insert(index, instertString);
			
			testList.RemoveAt(index);

			for (int i = 0; i < testList.Count; i++)
				Trace.Assert(((string)testList[i]) == testStrings[i], "TestLinkedListRemoveAt: Failed");

			TestPassed();
		}

		private void TestLinkedListCount()
		{
			Console.Write("Testing LinkedList.Count Property...");

			int listCount   = testList.Count;
			int arrayLength = testStrings.Length;

			Trace.Assert(listCount == arrayLength, "TestLinkedListCount: Failed");

			TestPassed();
		}

		private void TestLinkedListClone()
		{
			Console.Write("Testing LinkedList.Clone() Method...");

			LinkedList clonedList = (LinkedList)testList.Clone();

			for (int i = 0; i < clonedList.Count; i++)
				Trace.Assert(((string)clonedList[i]) == testStrings[i], "TestLinkedListClone: Shallow Clone Failed");

			LinkedList deepTestList = new LinkedList();

			for (int i = 0; i < 10; i++)
				deepTestList.Add(new DeepCloneClass(5));

			clonedList = deepTestList.Clone(true);

			for (int i = 0; i < clonedList.Count; i++)
				Trace.Assert(clonedList[i] != deepTestList[i], "TestLinkedListClone: Attempted Deep Clone Failed");

			TestPassed();
		}
		#endregion

		#region Private Member Classes
		private class DeepCloneClass : ICloneable
		{
			private int hiddenNumber;

			public DeepCloneClass(int number)
			{
				hiddenNumber = number;
			}
			
			public virtual object Clone()
			{			
				return new DeepCloneClass(this.hiddenNumber);
			}
		}
		#endregion
	}
}
