using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Queues
{
	/// <summary>
	/// Acts as simple server object.
	/// </summary>
	public class MyServer
	{
		private BlockingQueue inQ;			// Inbound Packets from client/Listener.
		private BlockingQueue outQ;			// Outgoing Packets back to client/Listener.
		private Thread thread;				// Server thread.
		private volatile bool stopped;		// Server stopped?
		private readonly object syncRoot;	// Sync object.

		public MyServer(BlockingQueue inQ, BlockingQueue outQ)
		{
			if ( inQ == null ) throw new ArgumentNullException("inQ");
			if ( outQ == null ) throw new ArgumentNullException("outQ");
			this.inQ = inQ;
			this.outQ = outQ;
			this.stopped = false;
			syncRoot = new object();
		}

		public void Start()
		{
			thread = new Thread(new ThreadStart(Run));
			thread.Start();
		}

		public void Stop()
		{
			lock(syncRoot)
			{
				stopped = true;
			}
		}
		
		public bool IsStopped
		{
			get
			{
				lock(syncRoot) { return this.stopped; }
			}
		}

		/// <summary>
		/// Entrypoint of server thread.
		/// </summary>
		private void Run()
		{
			Console.WriteLine("Server Started...");
			while( ! IsStopped )
			{
				// Input.
				InputObject inObj = inQ.Dequeue() as InputObject;
				if ( inObj == null )
					continue;

				// Process.
				Console.WriteLine(String.Format("Server got {0} bytes from client {1}",
					inObj.Packet.Length,
					inObj.ipEndPoint.Address.ToString()));

				// Output.
				outQ.Enqueue(inObj);
			}
			Console.WriteLine("Server Stopped...");
		}
	}

	/// <summary>
	/// Listener object that contains its own thread.  This does both Send and receive to
	/// make is short, but you could have a Sender object instead on another thread.
	/// </summary>
	public class MyListener
	{
		private IPAddress ipAddress;	// Listen address.
		private int port;				// Listen port.
		private Thread thread;
		private volatile bool stopped;
		private UdpClient udpClient;
		private BlockingQueue outQ;		// Output Queue to put objects received from the network.
		private BlockingQueue inQ;		// Input Queue that Server thread wants to send back to client.
		private readonly object syncRoot;

		public MyListener(IPAddress ipAddress, BlockingQueue outQ, BlockingQueue inQ)
		{
			// TODO: Validation
			thread = new Thread(new ThreadStart(Run));
			port = 55; // Some port.
			this.ipAddress = ipAddress;
			this.stopped = false;
			this.outQ = outQ;
			this.inQ = inQ;
			syncRoot = new object();
		}

		public void Start()
		{
			// Setup your UDP Client using IP and port...
			IPEndPoint iep = new IPEndPoint(this.ipAddress, this.port);
			udpClient = new UdpClient(iep);
		
			thread.Start();
		}

		public void Stop()
		{
			lock(syncRoot)
			{
				this.stopped = true;
				udpClient.Close();
			}
		}

		public bool IsStopped
		{
			get
			{
				lock(syncRoot) { return this.stopped; }
			}
		}

		private void Run()
		{
			Console.WriteLine("Listener Started...");
			IPEndPoint remoteEP = null;	// Endpoint of remote client that sent data.
			byte[] buffer = null;

			// Thread will block waiting on UPD packets and block on queue if full.
			while( ! IsStopped )
			{
				Thread.Sleep(100);	// Just to slow it down for testing.

				// buffer = udpClient.Receive(ref remoteEP);
				remoteEP = new IPEndPoint(IPAddress.Parse("192.168.0.2"), 3333); // for testing
				buffer = new byte[]{ 1, 2, 3, 4, 5, 6 };	// Fake some data for testing.
				if ( buffer == null || buffer.Length == 0 )
					continue;

				// TODO: Any other checks and Exception checking.
				InputObject iObj = new InputObject();
				iObj.Packet = buffer;
				iObj.ipEndPoint = remoteEP;
			
				// Put packet object in inQ for server thread.
				// Server thread will unblock when we put objects into the queue.
				outQ.Enqueue(iObj);

				// Get any Input from Server to send to client.
				object outObj;
				if ( ! inQ.TryDequeue(out outObj) )
					continue;
				InputObject tmpObj = outObj as InputObject;
				if ( tmpObj == null )
					continue;
				Console.WriteLine("Sending data to client " + tmpObj.ipEndPoint.Address.ToString());
				outObj = null;
			}
			Console.WriteLine("Listener Stopped...");
		}
	} // MyListener Class

	/// <summary>
	/// Name this class what ever.  Used to "wrap" the packet in a Transfer object to also
	/// carry along the Endpoint of the client.  Not actually required for this simple test.
	/// </summary>
	public class InputObject
	{
		public byte[] Packet;			// Inbound packet.
		public IPEndPoint ipEndPoint;	// EndPoint of client.
	}
}
