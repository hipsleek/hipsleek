./configure
sudo make install-strip
sudo cp mona_predicates.mona /usr/local/lib/
